package com.ubosque.tiendagenerica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendagenericaApplicationTests {

	@Test
	void contextLoads() {
	}

}
